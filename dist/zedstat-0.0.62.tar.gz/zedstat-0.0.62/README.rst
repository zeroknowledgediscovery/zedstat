===============
zedstat
===============

.. image:: https://zed.uchicago.edu/logo/logo_zedstat.png
   :height: 150px
   :align: center 

.. image:: https://zenodo.org/badge/529991779.svg
   :target: https://zenodo.org/badge/latestdoi/529991779

.. class:: no-web no-pdf

:Author: ZeD@UChicago <zed.uchicago.edu>
:Description: Tools for ML statistics 
:Documentation: https://zeroknowledgediscovery.github.io/zedstat/

**Usage:**

.. code-block::

   from zedstat.zedstat import zedstat

