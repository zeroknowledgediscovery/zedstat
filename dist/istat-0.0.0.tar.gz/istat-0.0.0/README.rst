===============
istat
===============

.. image:: https://zenodo.org/badge/526971595.svg
   :target: https://zenodo.org/badge/latestdoi/526971595

.. class:: no-web no-pdf

:Author: ZeD@UChicago <zed.uchicago.edu>
:Description: Tools for ML statistics 
:Documentation: https://zeroknowledgediscovery.github.io/istat/

**Usage:**

.. code-block::

   from istat import istat

