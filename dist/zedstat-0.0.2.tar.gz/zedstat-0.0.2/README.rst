===============
istat
===============

.. image:: https://zenodo.org/badge/526971595.svg
   :target: https://zenodo.org/badge/latestdoi/526971595

.. class:: no-web no-pdf

:Author: ZeD@UChicago <zed.uchicago.edu>
:Description: Tools for ML statistics 
:Documentation: https://zeroknowledgediscovery.github.io/zedstat/

**Usage:**

.. code-block::

   from zedstat.zedstat import zedstat

